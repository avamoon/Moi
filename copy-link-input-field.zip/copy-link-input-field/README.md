# Copy Link Input Field

A Pen created on CodePen.io. Original URL: [https://codepen.io/dcode-software/pen/eYMYXrK](https://codepen.io/dcode-software/pen/eYMYXrK).

